"""
Q7: Higher-order functions simplify code
"""

def apply_operation(data, func):
    return [func(x) for x in data]

print("Squared values:", apply_operation([1, 2, 3], lambda x: x * x))
