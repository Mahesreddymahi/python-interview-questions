"""
Q1: How would you optimize a recursive function to avoid maximum recursion depth errors in Python?
"""

# You can use tail recursion (though Python does not optimize it), or convert to iteration.
# Another option is to use sys.setrecursionlimit() with caution, or refactor to iteration.

import sys

# Example: Calculating factorial iteratively instead of recursively
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

print("Factorial (iterative) of 5:", factorial_iterative(5))
