"""
Q9: Refactor deeply nested loops using functions
"""

def process_matrix(matrix):
    for row in matrix:
        handle_row(row)

def handle_row(row):
    for val in row:
        print(f"Value: {val}")

matrix = [[1, 2], [3, 4]]
process_matrix(matrix)
