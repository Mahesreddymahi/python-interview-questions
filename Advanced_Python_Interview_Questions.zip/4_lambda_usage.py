"""
Q4: When would you use a lambda function over a regular function in a production codebase?
"""

# Example: Sorting with key
names = ["Charlie", "Alice", "Bob"]
names.sort(key=lambda name: name.lower())
print("Sorted names:", names)
