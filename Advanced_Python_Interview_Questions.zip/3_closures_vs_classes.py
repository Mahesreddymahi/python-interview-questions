"""
Q3: Explain how closures work in Python. Give a real-time example where closures are better than classes.
"""

def outer_function(multiplier):
    def inner_function(number):
        return number * multiplier
    return inner_function

double = outer_function(2)
triple = outer_function(3)
print("Double 5:", double(5))
print("Triple 5:", triple(5))
