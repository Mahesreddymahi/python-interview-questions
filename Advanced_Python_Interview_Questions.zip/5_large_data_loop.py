"""
Q5: Handle performance issues in loops due to large data processing.
"""

# Use generators and efficient data structures
def process_large_data(data):
    return [x * 2 for x in data if x % 2 == 0]

data = range(1000000)
result = process_large_data(data)
print("Processed first 5 items:", result[:5])
