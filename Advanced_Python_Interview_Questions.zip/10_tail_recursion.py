"""
Q10: Tail recursion, and converting to iteration
"""

# Tail recursion not optimized in Python; use iteration
def sum_iterative(n, acc=0):
    while n > 0:
        acc += n
        n -= 1
    return acc

print("Sum of first 5 numbers:", sum_iterative(5))
