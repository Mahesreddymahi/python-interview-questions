"""
Q2: Difference between *args and **kwargs and using both in one function.
"""

def demo_function(*args, **kwargs):
    print("Arguments (args):", args)
    print("Keyword Arguments (kwargs):", kwargs)

demo_function(1, 2, 3, name="Alice", age=25)
