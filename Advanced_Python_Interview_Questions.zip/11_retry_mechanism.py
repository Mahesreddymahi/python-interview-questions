"""
Q11: Retry mechanism for a function that might fail intermittently
"""

import time
import random

def retry(func, retries=3, delay=1):
    for i in range(retries):
        try:
            return func()
        except Exception as e:
            print(f"Attempt {i+1} failed: {e}")
            time.sleep(delay)
    raise Exception("All retries failed")

def flaky_function():
    if random.random() < 0.7:
        raise ValueError("Random failure")
    return "Success!"

print("Result:", retry(flaky_function))
